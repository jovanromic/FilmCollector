
recls 100% .NET - http://www.recls.net/

README
======

Updated:    11th November 2009



recls 100% .NET is a 100%-pure .NET library that provides recursive,
multi-pattern, file-system searches. It is written to production-quality
standards.

recls 100% .NET is donationware - see
http://en.wikipedia.org/wiki/Donationware - which means that it is free to
use without restriction (including in commercial software systems), but that
you are asked to make a modest donation (we suggest $50) if you find it
useful; see the PLEASE_DONATE.txt file in this distribution.

=============================== End of file ================================
